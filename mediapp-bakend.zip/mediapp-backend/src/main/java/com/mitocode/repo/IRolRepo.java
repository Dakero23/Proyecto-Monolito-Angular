package com.mitocode.repo;

import com.mitocode.model.Rol;

public interface IRolRepo extends IGenericRepo<Rol, Integer>{

	
}
