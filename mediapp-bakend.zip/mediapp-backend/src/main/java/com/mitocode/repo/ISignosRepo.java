package com.mitocode.repo;

import com.mitocode.model.Signos;


public interface ISignosRepo extends IGenericRepo<Signos, Integer>  {
	
}
