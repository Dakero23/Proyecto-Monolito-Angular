package com.mitocode.repo;

import com.mitocode.model.Medico;

public interface IMedicoRepo extends IGenericRepo<Medico, Integer>{

}
