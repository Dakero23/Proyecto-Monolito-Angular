package com.mitocode.repo;

import com.mitocode.model.Especialidad;

public interface IEspecialidadRepo extends IGenericRepo<Especialidad, Integer>{

}
