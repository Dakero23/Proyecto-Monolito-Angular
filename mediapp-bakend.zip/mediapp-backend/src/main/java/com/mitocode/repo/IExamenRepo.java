package com.mitocode.repo;

import com.mitocode.model.Examen;

public interface IExamenRepo extends IGenericRepo<Examen, Integer>{

}
